
package br.com.julianoceconi.EX05;

import javax.swing.JOptionPane;
import br.com.julianoceconi.EX05.Pilha;
        
public class Deposito {
    
    private Pilha<Produto>[] pilhas;
    private int numPilhas;
    
    public Deposito(int numPilhas, int tamanhoPilha) {
        this.numPilhas = numPilhas;
        pilhas = new Pilha[numPilhas];
        
        for (int i = 0; i < numPilhas; i++) {
            pilhas[i] = new Pilha<>(tamanhoPilha, "Pilha " + (i + 1));
        }
    }
    
    public void adicionaProduto(int indicePilha, Produto produto){
        if (indicePilha < 0 || indicePilha >= numPilhas) {
            JOptionPane.showMessageDialog(null, "Índice de pilha inválido!");
            return;
        }
        Pilha<Produto> pilha = pilhas[indicePilha];
        if (pilha.isFull()) {
            JOptionPane.showMessageDialog
        (null, "A pilha " + pilha.getNome() 
                + " está cheia, não é possível adicionar mais produtos!");
            return;
        }
        pilha.push(produto);
        JOptionPane.showMessageDialog
            (null, "Produto " + produto + " adicionado à " + pilha.getNome());
        listarProdutos();
    }
    
    public void listarProdutos(){
        StringBuilder mensagem = new StringBuilder("Produtos nas pilhas:\n");
        for (Pilha<Produto> pilha : pilhas) {
            mensagem.append(pilha.getNome()).append(":\n");
            if(pilha.isEmpty()){
                mensagem.append("  A pilha está vazia!\n");
            }else{
                for(int i = pilha.size() - 1; i >= 0; i--){
                    mensagem.append("  ").append(pilha.get(i)).append("\n");
                }
            }
        }
        JOptionPane.showMessageDialog(null, mensagem.toString());
    }
    
    public void retirarProduto(int indicePilha){
        if (indicePilha < 0 || indicePilha >= numPilhas) {
            JOptionPane.showMessageDialog(null, "Índice de pilha inválido!");
            return;
        }
        Pilha<Produto> pilha = pilhas[indicePilha];
        if(pilha.isEmpty()){
            JOptionPane.showMessageDialog
            (null, "A pilha " + pilha.getNome() + " está vazia!");
            return;
        }
        Produto produtoRemovido = pilha.pop();
        JOptionPane.showMessageDialog(null, "Produto removido da "
                        + pilha.getNome() + ": " + produtoRemovido);
        listarProdutos();
    }
    
}
