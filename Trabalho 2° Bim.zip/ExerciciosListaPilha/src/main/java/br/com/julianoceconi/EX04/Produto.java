
package br.com.julianoceconi.EX04;

public class Produto {
    
    private String codProduto;
    private String descricao;
    private String dataEntrada;
    private String ufOrigem;
    private String ufDestino;

    public Produto(String codProduto, String descricao, String dataEntrada, 
                                           String ufOrigem, String ufDestino) {
        this.codProduto = codProduto;
        this.descricao = descricao;
        this.dataEntrada = dataEntrada;
        this.ufOrigem = ufOrigem;
        this.ufDestino = ufDestino;
    }

    @Override
    public String toString() {
        return "\nCodigo Produto = " + codProduto + "\nDescricao = "
                + descricao + "\nData de Entrada = " + dataEntrada + 
                "\nUF de Origem = " + ufOrigem + "\nUF de Destino = "
                + ufDestino;
    }

    
    
}
