
package br.com.julianoceconi.EX01;

import javax.swing.JOptionPane;

public class FilaDaClinica {

    private String[] fila;
    private int frente;
    private int fim;
    private int qtdItens;

    public FilaDaClinica(int capacidade) {
        fila = new String[capacidade];
        frente = 0;
        fim = -1;
        qtdItens = 0;
    }
    
     public boolean isEmpty() {
        return qtdItens == 0;
    }

    public boolean isFull() {
        return qtdItens == fila.length;
    }

    public void enqueue(String elemento) {
        if (!isFull()) {
            if (fim == fila.length - 1) {
                fim = -1;
            }
            fila[++fim] = elemento;
            qtdItens++;
        } else {
            JOptionPane.showMessageDialog
          (null, "A fila está cheia. Não é possível adicionar mais pacientes.");
        }
    }
    
    public String dequeue() {
        if (!isEmpty()) {
            String elemento = fila[frente++];
            if (frente == fila.length) {
                frente = 0;
            }
            qtdItens--;
            return elemento;
        } else {
            JOptionPane.showMessageDialog(null, "A fila está vazia.");
            return null;
        }
    }
    
 
    public static void main(String[] args) {

        FilaDaClinica fila = new FilaDaClinica(20);
        
        int opcao;
        
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog
            ("Selecione o que deseja fazer"
                    + "\n1 - Adicionar paciente na fila"
                    + "\n2 - Chamar o próximo paciente"
                    + "\n0 - Sair do programa"));
            
            switch(opcao){
                case 1:
                    String nome = JOptionPane.showInputDialog
                    ("Insira o nome do paciente para ser adicionado na fila: ");
                    fila.enqueue(nome);
                    break;
                    
                case 2:
                    String proximo = fila.dequeue();
                    if (proximo != null) {
                        JOptionPane.showMessageDialog
                            (null, "Proximo paciente: " + proximo);
                    }
                    break;
                    
                case 0:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                            
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!!");
            }         
            
        }while(opcao != 0);
        
    }
}
