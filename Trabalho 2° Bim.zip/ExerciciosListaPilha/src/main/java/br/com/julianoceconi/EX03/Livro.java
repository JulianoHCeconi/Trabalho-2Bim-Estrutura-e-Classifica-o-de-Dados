
package br.com.julianoceconi.EX03;


class Livro {
    
    private String titulo;

    public Livro(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return this.titulo;
    }
    
    
    
}
