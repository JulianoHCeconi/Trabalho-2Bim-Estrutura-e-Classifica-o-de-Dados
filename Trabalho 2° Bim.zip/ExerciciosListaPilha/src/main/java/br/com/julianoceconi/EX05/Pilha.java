
package br.com.julianoceconi.EX05;

public class Pilha<Pilhas>{
    
    private Pilhas[] pilha;
    private int posicaoTopo;
    private String nome;
    
    @SuppressWarnings("unchecked")
    public Pilha(int tamanho, String nome) {
        pilha = (Pilhas[]) new Object[tamanho];
        posicaoTopo = -1;
        this.nome = nome;
    }
    
    public void push(Pilhas elemento){
        pilha[++posicaoTopo] = elemento;
    }
    
    public int size(){
        return posicaoTopo + 1;
    }
    
    public Pilhas get(int index) {
        if (index < 0 || index > posicaoTopo) {
            throw new IndexOutOfBoundsException("Índice fora dos limites");
        }
        return pilha[index];
    }
    
    public Pilhas pop(){
        if (isEmpty()) {
            throw new RuntimeException("Pilha está vazia");
        }
        return pilha[posicaoTopo--];
    }
    
    public Pilhas top(){
        if (isEmpty()) {
            throw new RuntimeException("Pilha está vazia");
        }
        return pilha[posicaoTopo];
    }
    
    public boolean isEmpty(){
        return posicaoTopo == -1;  
    }
      
    public boolean isFull(){
        return posicaoTopo == pilha.length - 1;
    }

    public String getNome() {
        return nome;
    }
}
