
package br.com.julianoceconi.EX04;

import javax.swing.JOptionPane;

public class MAIN {
    
    public static void main(String[]args){
        
        Deposito deposito = new Deposito(10);
        
        int opcao;
        
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog
                ("Escolha uma opcção: "
                        + "\n 1 - Adicionar produto a pilha"
                        + "\n 2 - Listar produtos da pilha"
                        + "\n 3 - Remover produtos da pilha"
                        + "\n 0 - Sair"));
        
            switch(opcao){
                
                case 1:
                    String codProduto = JOptionPane.showInputDialog
                                    ("Digite o código do produto:");
                    String descricao = JOptionPane.showInputDialog
                                    ("Digite a descrição do produto:");
                    String dataEntrada = JOptionPane.showInputDialog
                                    ("Digite a data de entrada (dd/mm/aaaa):");
                    String ufOrigem = JOptionPane.showInputDialog
                                    ("Digite a UF de origem:");
                    String ufDestino = JOptionPane.showInputDialog
                                    ("Digite a UF de destino:");
                    
                    Produto produto = new Produto
                    (codProduto, descricao, dataEntrada, ufOrigem, ufDestino);
                    deposito.adicionaProduto(produto);
                    break;
                    
                case 2:
                    deposito.listarProdutos();
                    break;
                case 3:
                    deposito.retirarProduto();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!!");       
            }
        }while(opcao != 0);
        
    }
    
}
