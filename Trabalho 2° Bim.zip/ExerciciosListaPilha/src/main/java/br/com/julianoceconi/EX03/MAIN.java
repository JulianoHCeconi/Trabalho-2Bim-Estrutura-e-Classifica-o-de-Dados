
package br.com.julianoceconi.EX03;

import javax.swing.JOptionPane;

public class MAIN {
    
    public static void main(String[]args){
        
        int tamanhoDaPilha = Integer.parseInt(JOptionPane.showInputDialog
                                        ("Informe o tamanho da pilha: "));
        
        Biblioteca biblioteca = new Biblioteca(tamanhoDaPilha);
        
        int opcao;
        
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog
                ("Escolha uma opção"
                        + "\n 1 - Adicionar livro"
                        + "\n 2 - Remover livro"
                        + "\n 3 - Listar livro"
                        + "\n 0 - Sair"));
            
            switch(opcao){
                case 1: 
                    String titulo = JOptionPane.showInputDialog
                                    ("Informe o titulo do livro");
                    Livro livro = new Livro(titulo);
                    biblioteca.adiconarLivro(livro);
                    break;
                    
                case 2:
                    biblioteca.retirarLivro();
                    break;
                    
                case 3:
                    biblioteca.listar();
                    break;
                
                case 0:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opcao invalida!");
            }
            
        }while(opcao != 0);
        
    }
    
}
