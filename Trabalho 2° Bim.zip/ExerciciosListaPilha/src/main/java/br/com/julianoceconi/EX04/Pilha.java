
package br.com.julianoceconi.EX04;


public class Pilha<Pilha> {
    
    private Pilha[] pilha;
    private int posicaoTopo;
    
    public Pilha(int tamanho) {
        pilha = (Pilha[]) new Object[tamanho];
        posicaoTopo = -1;
    }
    
    public void push(Pilha elemento){
        pilha[++posicaoTopo] = elemento;
    }
    
    public int size(){
        return posicaoTopo + 1;
    }
    
    public Pilha get(int index) {
        if (index < 0 || index > posicaoTopo) {
        }
        return pilha[index];
    }
    
    public Pilha pop(){
        return pilha[posicaoTopo--];
    }
    
    public Pilha top(){
        return pilha[posicaoTopo];
    }
    
    public boolean isEmpty(){
      return posicaoTopo == -1;  
    }
      
    public boolean isFull(){
        return posicaoTopo == pilha.length-1;
    }
    
    
    
}
