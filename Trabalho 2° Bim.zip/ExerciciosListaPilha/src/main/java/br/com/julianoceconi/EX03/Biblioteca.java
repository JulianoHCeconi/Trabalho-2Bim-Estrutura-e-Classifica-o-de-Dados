
package br.com.julianoceconi.EX03;

import javax.swing.JOptionPane;

public class Biblioteca {
    
    private Pilha<Livro> pilhaDosLivros;

    public Biblioteca(int tamanho) {
        this.pilhaDosLivros = new Pilha<>(tamanho);
    }
    
    public void adiconarLivro(Livro livro){
        pilhaDosLivros.push(livro);
        JOptionPane.showMessageDialog(null, "Livro " + livro + " adicionado!");
    }
    
    public void listar(){
        if(pilhaDosLivros.isEmpty()){
            JOptionPane.showMessageDialog(null, "A pilha esta vazia!!");
        }else{
            for(int i = pilhaDosLivros.size() - 1; i>0; i++){
                JOptionPane.showMessageDialog
                  (null, "Livros na pilha: \n" + pilhaDosLivros.get(i) + "\n");
            }
        }
    }
    
    public void retirarLivro() {
        if (pilhaDosLivros.isEmpty()) {
            JOptionPane.showMessageDialog
            (null, "A pilha de livros está vazia, nenhum livro para remover.");
        } else {
            Livro livroRemovido = pilhaDosLivros.pop();
            JOptionPane.showMessageDialog
                        (null, "Livro removido: " + livroRemovido);
        }
    }
    
    
    
}
