
package br.com.julianoceconi.EX05;

import javax.swing.JOptionPane;

public class Main {
    
    public static void main(String[] args){
        
        int numPilhas = 5;
        int tamanhoPilha = 10;
        
        Deposito deposito = new Deposito(numPilhas, tamanhoPilha);
        
        int opcao;
        
        do{
            String menu = "Escolha uma opção: \n"
                        + "1 - Adicionar produto a uma pilha\n"
                        + "2 - Listar produtos nas pilhas\n"
                        + "3 - Remover produto de uma pilha\n"
                        + "0 - Sair";
            opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));
        
            switch(opcao){
                
                case 1:
                    int indicePilhaAdd = Integer.parseInt
                    (JOptionPane.showInputDialog
                   ("Digite o índice da pilha (0 a " + (numPilhas - 1) + "):"));
                    String codProduto = JOptionPane.showInputDialog
                                                ("Digite o código do produto:");
                    String descricao = JOptionPane.showInputDialog
                                             ("Digite a descrição do produto:");
                    String dataEntrada = JOptionPane.showInputDialog
                                    ("Digite a data de entrada (dd/mm/aaaa):");
                    String ufOrigem = JOptionPane.showInputDialog
                                                ("Digite a UF de origem:");
                    String ufDestino = JOptionPane.showInputDialog
                                                    ("Digite a UF de destino:");
                    
                    Produto produto = new Produto(codProduto, descricao,
                    dataEntrada, ufOrigem, ufDestino);
                    deposito.adicionaProduto(indicePilhaAdd, produto);
                    break;
                    
                case 2:
                    deposito.listarProdutos();
                    break;
                    
                case 3:
                    int indicePilhaRemover = Integer.parseInt
                    (JOptionPane.showInputDialog
                   ("Digite o índice da pilha (0 a " + (numPilhas - 1) + "):"));
                    deposito.retirarProduto(indicePilhaRemover);
                    break;
                    
                case 0:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!!");
            }
        } while(opcao != 0);
    }
    
}
