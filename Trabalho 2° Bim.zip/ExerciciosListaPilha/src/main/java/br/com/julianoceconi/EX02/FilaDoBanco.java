
package br.com.julianoceconi.EX02;

import javax.swing.JOptionPane;

class ClienteDoBanco {
    
    int senha;
    String nome;
    int anoNascimento;

    public ClienteDoBanco(int senha, String nome, int anoNascimento) {
        this.senha = senha;
        this.nome = nome;
        this.anoNascimento = anoNascimento;
    } 
}

public class FilaDoBanco{
    private ClienteDoBanco[] filaPrioritaria;
    private ClienteDoBanco[] filaNormal;
    private int frentePrioritaria;
    private int frenteNormal;
    private int fimPrioritaria;
    private int fimNormal;
    private int qtdPrioritaria;
    private int qtdNormal;
    
    public FilaDoBanco(int capacidade) {
        filaPrioritaria = new ClienteDoBanco[capacidade];
        filaNormal = new ClienteDoBanco[capacidade];
        frentePrioritaria = 0;
        fimPrioritaria = -1;
        frenteNormal = 0;
        fimNormal = -1;
        qtdPrioritaria = 0;
        qtdNormal = 0;
}
    
    public boolean isEmptyPrioritaria() {
        return qtdPrioritaria == 0;
    }

    public boolean isEmptyNormal() {
        return qtdNormal == 0;
    }

    public boolean isFullPrioritaria() {
        return qtdPrioritaria == filaPrioritaria.length;
    }

    public boolean isFullNormal() {
        return qtdNormal == filaNormal.length;
    }
        
    
    public void enqueuePrioritario(ClienteDoBanco cliente){
        if(!isFullPrioritaria()){
            if(fimPrioritaria == filaPrioritaria.length -1){
            fimPrioritaria = -1;
            }
            filaPrioritaria[++fimPrioritaria] = cliente;
            qtdPrioritaria++;
        }else{
            JOptionPane.showMessageDialog
                    (null, "A fila de pacientes prioritarios ja esta cheia!!");
    }
}
    
    public void enqueueNormal(ClienteDoBanco cliente){
        if(!isFullNormal()){
            if(fimNormal == filaNormal.length -1){
                fimNormal = -1;
            }
            filaNormal[++fimNormal] = cliente;
            qtdNormal++;
        }else{
            JOptionPane.showMessageDialog(null, "A fila normal ja está cheia");
        }
    }

    public ClienteDoBanco dequeuePrioritaria(){
        if(!isEmptyPrioritaria()){
            ClienteDoBanco cliente = filaPrioritaria[frentePrioritaria++];
            if(frentePrioritaria == filaPrioritaria.length){
                frentePrioritaria = 0;
            }
            qtdPrioritaria--;
            return cliente;
        }else{
            JOptionPane.showMessageDialog
                    (null, "A fila de prioridades está vazia!!");
            return null;
        }
    }
    
    public ClienteDoBanco dequeueNormal(){
        if(!isEmptyNormal()){
            ClienteDoBanco cliente = filaNormal[frenteNormal++];
            if(frenteNormal == filaNormal.length){
                frenteNormal = 0;
            }
            qtdNormal--;
            return cliente;
        }else{
            JOptionPane.showMessageDialog(null, "A fila normal está vazia!!");
            return null;
        }
    }
    
    public static void main(String[]args){
        
        FilaDoBanco controleDaFila = new FilaDoBanco(20);
        
        int atendidos = 0;
        int opcao;
        
        do{
            opcao = Integer.parseInt(JOptionPane.showInputDialog
            ("Selecione o que deseja fazer"
                    + "\n1 - Adicionar um cliente"
                    + "\n2 - Chamar próximo cliente"
                    + "\n0 - Sair   "));
            
            switch(opcao){
                
                case 1:
                    String nome = JOptionPane.showInputDialog
                                    ("Informe o nome do cliente:");
                    int anoNascimento = Integer.parseInt
                                (JOptionPane.showInputDialog
                                ("Informe a data de nascimento do clinete: "));
                    int senha = Integer.parseInt(JOptionPane.showInputDialog
                                    ("Informe a senha do cliente:"));
                    ClienteDoBanco cliente = new ClienteDoBanco
                                                (senha, nome, anoNascimento);
                    if(cliente.anoNascimento <= 1957){
                        controleDaFila.enqueuePrioritario(cliente);
                    }else{
                        controleDaFila.enqueueNormal(cliente);
                    }
                    break;
                    
                case 2:
                    if(!controleDaFila.isEmptyPrioritaria()){
                        atendimento(controleDaFila.dequeuePrioritaria());
                        atendidos++;
                    }else if(!controleDaFila.isEmptyNormal()){
                        atendimento(controleDaFila.dequeueNormal());
                        atendidos++;
                    }else{
                        JOptionPane.showMessageDialog
                                (null, "Não tem ninguém na fila");
                    }
                    
                    if(atendidos % 2 == 0 && atendidos > 0){
                        if(!controleDaFila.isEmptyNormal()){
                            atendimento(controleDaFila.dequeueNormal());
                            atendidos++;
                        }
                    }
                    break;
                    
                case 0:
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                    
                default:
                    JOptionPane.showMessageDialog(null, "Opção inválida!!");
            }            
    
        }while(opcao != 0);
      
    }
    
    private static void atendimento(ClienteDoBanco cliente) {
        JOptionPane.showMessageDialog(null, "Cliente atendido:\n" +
                "Nome: " + cliente.nome + "\n" +
                "Senha: " + cliente.senha + "\n" +
                "Ano de Nascimento: " + cliente.anoNascimento);
    }
    
    
}