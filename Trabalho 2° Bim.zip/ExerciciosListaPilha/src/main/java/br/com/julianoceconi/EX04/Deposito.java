
package br.com.julianoceconi.EX04;

import javax.swing.JOptionPane;

public class Deposito {
    
    private Pilha<Produto> pilhaDosProdutos;

    public Deposito(int tamanho) {
        this.pilhaDosProdutos = new Pilha<>(tamanho);
    }
    
    public void adicionaProduto(Produto produto){
        if (pilhaDosProdutos.isFull()) {
            JOptionPane.showMessageDialog
          (null, "A pilha está cheia, não é possível adicionar mais produtos!");
            return;
        }
        pilhaDosProdutos.push(produto);
        JOptionPane.showMessageDialog
                            (null, "Produto " + produto + " adicionado!");
        listarProdutos();
    }
    
    public void listarProdutos(){
        if(pilhaDosProdutos.isEmpty()){
            JOptionPane.showMessageDialog(null, "A pilha está vazia!");
        }else{
            StringBuilder mensagem = new StringBuilder("Produtos na pilha:\n");
            for(int i = pilhaDosProdutos.size() - 1; i >= 0; i--){
                mensagem.append(pilhaDosProdutos.get(i)).append("\n");
            }
            JOptionPane.showMessageDialog(null, mensagem.toString());
        }
    }
    
    public void retirarProduto(){
        if(pilhaDosProdutos.isEmpty()){
            JOptionPane.showMessageDialog(null, "Não há nada para remover!!");
        }else{
            Produto produtoRemovido = pilhaDosProdutos.pop();
            JOptionPane.showMessageDialog
            (null, "Produto removido: " + produtoRemovido);
            listarProdutos();
        }
    }
    
}
